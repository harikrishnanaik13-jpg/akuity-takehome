# Submission notes

Before submitting:

1. Create a GitHub repository.
2. Push this repo.
3. Replace `REPLACE_ME` in the manifests with your GitHub org/user.
4. Run `grep -R "REPLACE_ME" -n .` and confirm no placeholders remain.
5. Run the bootstrap script against a test cluster.
6. Verify Argo CD apps are healthy.
7. Verify custom Helm version in repo-server.
8. Verify Prometheus targets and alerts.
9. Submit the GitHub repository link in Greenhouse.

Suggested panel explanation:

- I used a bootstrap step because Argo CD cannot manage itself before it exists.
- After bootstrap, the root Application points Argo CD back to Git and it manages itself using the app-of-apps pattern.
- Prometheus is deployed by Argo CD, and Argo CD monitoring resources are separated so they can be adjusted independently.
- Helm replacement is implemented at the repo-server because repo-server is responsible for manifest generation.
- I included troubleshooting notes because the role is support-focused, so the repo should help another engineer debug the system quickly.
