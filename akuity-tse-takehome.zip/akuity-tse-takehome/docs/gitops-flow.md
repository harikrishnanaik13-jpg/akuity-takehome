# End-to-end GitOps auto-sync flow in Argo CD

This document explains what happens when an Argo CD Application watches manifests in Git and an update is auto-synced into a Kubernetes cluster.

## Components involved

- **Git server**: Source of truth for desired state.
- **argocd-server**: API/UI/gRPC entry point used by users, CLI, and webhooks.
- **application-controller**: Main reconciliation engine. Compares desired state from Git with live state in Kubernetes and applies changes when sync is triggered.
- **repo-server**: Manifest generation service. Fetches Git content and renders plain YAML, Helm, Kustomize, or supported config-management output.
- **Kubernetes API server**: Cluster API where Argo CD reads live state and applies desired resources.

## Sequence diagram

```mermaid
sequenceDiagram
    actor User
    participant Git as Git server
    participant Server as argocd-server
    participant Controller as application-controller
    participant Repo as repo-server
    participant Kube as Kubernetes API server

    User->>Git: Push manifest/Helm/Kustomize change
    Git-->>Server: Optional webhook notifies Argo CD
    Controller->>Git: Poll/check Application source revision
    Controller->>Repo: Request manifests for repo/path/revision
    Repo->>Git: Fetch repository content
    Repo->>Repo: Render manifests using Helm/Kustomize/YAML
    Repo-->>Controller: Return desired manifests
    Controller->>Kube: Read live resource state
    Kube-->>Controller: Return current cluster objects/status
    Controller->>Controller: Compare desired vs live state
    alt Automated sync enabled and diff exists
        Controller->>Kube: Apply create/update/delete operations
        Kube-->>Controller: Return apply result
        Controller->>Kube: Watch resource status/health
        Kube-->>Controller: Return pod/deployment/service status
        Controller->>Server: Update Application status/history
    else No diff or manual sync only
        Controller->>Server: Report Synced or OutOfSync status
    end
    User->>Server: View app sync/health/history in UI or CLI
```

## Step-by-step explanation

### 1. A change is pushed to Git

A developer or automation updates Kubernetes manifests, Helm values, or Kustomize configuration and pushes the change to the tracked Git branch.

In GitOps, this Git change represents the new desired state.

### 2. Argo CD notices the change

Argo CD can detect the change by polling the Git repository or through a webhook delivered to `argocd-server`.

The `argocd-server` is not the component that performs the sync. It exposes API/UI access and can receive external requests, but reconciliation is handled by the `application-controller`.

### 3. application-controller starts reconciliation

The `application-controller` sees that the Application source revision may have changed. It begins the reconciliation loop for that Application.

Its job is to answer two questions:

1. What should exist according to Git?
2. What currently exists in the Kubernetes cluster?

### 4. repo-server renders desired manifests

The `application-controller` asks the `repo-server` to generate manifests for the Application source.

The `repo-server` fetches the Git content and renders the final Kubernetes manifests. If the app uses Helm, this is where Helm is executed. If the app uses Kustomize, this is where Kustomize builds the final output.

In this repository, the custom Helm binary replacement matters because Helm rendering happens in the `argocd-repo-server` container.

### 5. application-controller compares desired vs live state

The `application-controller` reads live objects from the Kubernetes API server and compares them against the desired manifests returned by `repo-server`.

If there is no difference, the Application remains `Synced`.

If there is a difference, the Application becomes `OutOfSync`.

### 6. Auto-sync applies the change

If automated sync is enabled, the `application-controller` applies the desired changes through the Kubernetes API server.

Depending on the diff, this may create, update, or prune resources.

### 7. Kubernetes schedules and runs the workload

The Kubernetes API server accepts the objects. Controllers inside Kubernetes then reconcile their own resources. For example:

- A Deployment creates or updates ReplicaSets.
- ReplicaSets create Pods.
- Services select matching Pod endpoints.
- Ingress controllers update routing configuration.

### 8. Argo CD evaluates health

After applying the manifests, Argo CD checks resource health using Kubernetes status fields and Argo CD health logic.

A common support case is:

```text
Synced but Degraded/Unhealthy
```

That means Git desired state was successfully applied, but the workload is not healthy at runtime. For example, a Deployment may have pods in `CrashLoopBackOff` due to a missing secret or bad config.

### 9. Status is visible to users

The updated Application status is visible through the Argo CD UI, CLI, and API via `argocd-server`.

Users can see sync status, health, history, events, and resource tree details.

## Support-engineer explanation

If a customer says auto-sync failed, I would avoid assuming Argo CD is broken. I would isolate the layer:

1. **Git problem**: wrong repo URL, branch, path, or invalid values.
2. **Manifest generation problem**: Helm/Kustomize rendering failure in repo-server.
3. **Kubernetes apply problem**: RBAC, missing CRDs, admission policy, quota, invalid resource.
4. **Runtime health problem**: pods crash, readiness fails, service endpoints missing, ingress/DNS issue.
5. **Argo control-plane problem**: controller/repo-server unavailable, Redis issues, cache/reconciliation lag.

The key support mindset is to separate **sync status** from **health status**:

- `OutOfSync`: desired state in Git differs from live state.
- `Synced but Unhealthy`: desired state was applied, but the workload is not healthy.
