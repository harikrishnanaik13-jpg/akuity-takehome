# Akuity Technical Support Engineer Take-Home Challenge

This repository contains a GitOps-based Kubernetes/Argo CD setup for the Akuity Technical Support Engineer take-home challenge.

The solution demonstrates:

1. Argo CD managing its own configuration/lifecycle after an initial bootstrap.
2. Prometheus monitoring for Argo CD, including ServiceMonitors, Prometheus alert rules, and a Grafana dashboard.
3. Replacing the Helm binary used by the Argo CD repo-server with a pinned custom Helm version.
4. A clear explanation of what happens end-to-end when an Argo CD Application auto-syncs a Git update into a Kubernetes cluster.

> **Important:** Before running this in your own cluster, update the placeholder Git repository URL in `bootstrap/root-application.yaml` and `apps/*.yaml` to your own public GitHub repository URL.

---

## Repository structure

```text
.
├── apps/
│   ├── argocd.yaml                     # Argo CD self-management Application
│   ├── monitoring-stack.yaml           # kube-prometheus-stack Application
│   └── argocd-observability.yaml       # ServiceMonitors, alerts, dashboard
├── bootstrap/
│   ├── install-argocd.sh               # One-time bootstrap script
│   └── root-application.yaml           # App-of-apps root Application
├── docs/
│   ├── gitops-flow.md                  # End-to-end GitOps sync explanation
│   └── troubleshooting.md              # Real-world troubleshooting notes
├── examples/
│   └── guestbook/                      # Small sample app for validation/demo
└── platform/
    ├── argocd/
    │   ├── base/                       # Argo CD install + repo-server Helm override
    │   └── overlays/default/
    └── monitoring/
        └── argocd-observability/       # Argo CD monitoring resources
```

---

## Assumptions

- A Kubernetes cluster is already available. This can be `kind`, `minikube`, EKS, GKE, or AKS.
- `kubectl` has access to the target cluster.
- The repo is pushed to GitHub or another Git server reachable by the cluster.
- Argo CD is installed in the `argocd` namespace.
- Monitoring is installed in the `monitoring` namespace.
- The Prometheus stack uses the Prometheus Operator CRDs from `kube-prometheus-stack`.
- For production, I would pin every upstream chart and manifest version, enable SSO/RBAC, configure secrets through an external secret manager, and avoid admin access as a day-to-day workflow.

---

## Quick start

### 1. Create a local test cluster

Optional, if you do not already have a cluster:

```bash
kind create cluster --name akuity-takehome
kubectl cluster-info
```

### 2. Update repository URL

Replace every instance of:

```text
https://github.com/REPLACE_ME/akuity-tse-takehome.git
```

with your actual repository URL.

You can check with:

```bash
grep -R "REPLACE_ME" -n .
```

### 3. Bootstrap Argo CD

The bootstrap step installs Argo CD once using the manifests in this repo, then creates a root Argo CD Application. After that, Argo CD manages itself and the rest of the platform from Git.

```bash
chmod +x bootstrap/install-argocd.sh
./bootstrap/install-argocd.sh
```

### 4. Verify Argo CD components

```bash
kubectl get pods -n argocd
kubectl get applications -n argocd
```

Expected Applications:

```text
argocd-self-managed
monitoring-stack
argocd-observability
```

### 5. Access Argo CD locally

```bash
kubectl -n argocd port-forward svc/argocd-server 8080:443
```

Get the initial admin password:

```bash
kubectl -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath='{.data.password}' | base64 -d && echo
```

Open:

```text
https://localhost:8080
```

### 6. Verify custom Helm binary in Argo CD repo-server

This challenge requires replacing the Helm binary included with Argo CD with a different version.

The repo-server deployment is patched with an init container that downloads Helm `v3.15.4` and mounts it over `/usr/local/bin/helm` inside the `argocd-repo-server` container.

Verify:

```bash
kubectl -n argocd exec deploy/argocd-repo-server -c argocd-repo-server -- helm version --short
```

Expected output should include:

```text
v3.15.4
```

### 7. Verify Prometheus monitoring

```bash
kubectl get pods -n monitoring
kubectl get servicemonitor -n monitoring
kubectl get prometheusrule -n monitoring
```

Port-forward Prometheus:

```bash
kubectl -n monitoring port-forward svc/monitoring-stack-kube-prom-prometheus 9090:9090
```

Open:

```text
http://localhost:9090/targets
```

Look for Argo CD targets such as:

- `argocd-server-metrics`
- `argocd-repo-server`
- `argocd-metrics`

Port-forward Grafana:

```bash
kubectl -n monitoring port-forward svc/monitoring-stack-grafana 3000:80
```

Open:

```text
http://localhost:3000
```

Default login from this demo values file:

```text
admin / prom-operator
```

---

## What I would troubleshoot in a real customer environment

If a customer reported that this was not working, I would approach it in layers:

1. **Git layer**
   - Confirm the repo URL is reachable.
   - Confirm the target revision and path are correct.
   - Confirm manifests render successfully.

2. **Argo CD layer**
   - Check Application sync status and health.
   - Check `argocd-metrics` logs for reconciliation errors.
   - Check `argocd-repo-server` logs for Helm/Kustomize rendering failures.

3. **Kubernetes layer**
   - Check events, CRDs, RBAC, namespaces, and pod status.
   - Confirm Prometheus Operator CRDs exist before applying `ServiceMonitor` and `PrometheusRule` resources.

4. **Monitoring layer**
   - Confirm Argo CD metrics services exist.
   - Confirm ServiceMonitor labels match the Prometheus selector.
   - Confirm targets are discovered in Prometheus.

More detail is included in [`docs/troubleshooting.md`](docs/troubleshooting.md).

---

## GitOps flow explanation

The end-to-end GitOps flow is documented in [`docs/gitops-flow.md`](docs/gitops-flow.md).

Short version:

1. A user pushes a manifest change to Git.
2. Argo CD detects the change by polling Git or receiving a webhook.
3. The application-controller requests rendered manifests from the repo-server.
4. The repo-server fetches Git content and renders manifests using Helm/Kustomize/plain YAML.
5. The application-controller compares desired state from Git with live state in Kubernetes.
6. If auto-sync is enabled, Argo CD applies the required changes through the Kubernetes API server.
7. Argo CD continues health checks and reports Synced/OutOfSync and Healthy/Degraded status.

---

## Notes for the panel discussion

The most important design choices I would highlight are:

- I used an **app-of-apps pattern** so the platform can be managed declaratively.
- Argo CD is **bootstrapped once**, then becomes **self-managed** through Git.
- Monitoring is installed as a separate Application so it can be owned and upgraded independently.
- Argo CD observability resources are separated from the Prometheus stack to make troubleshooting easier.
- The Helm binary override is visible, testable, and limited to the repo-server, which is the component responsible for manifest generation.
- Troubleshooting documentation is included because a support engineer should make fixes repeatable, not just make the demo work once.
