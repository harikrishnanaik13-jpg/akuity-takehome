# Troubleshooting notes

This file captures how I would troubleshoot the solution in a real customer environment.

## 1. Argo CD Application is OutOfSync

### Checks

```bash
kubectl -n argocd get application <app-name> -o yaml
kubectl -n argocd describe application <app-name>
```

### Likely causes

- Git contains changes not yet applied.
- Auto-sync is disabled.
- Resource was manually changed in the cluster.
- Prune is required for deleted resources.
- Argo CD lacks permissions to modify a resource.

### Support response

I would compare desired state from Git with live state in the cluster. If the diff is expected, I would sync or verify auto-sync. If drift came from manual cluster changes, I would explain that Git is the source of truth and recommend changing Git rather than patching live resources.

---

## 2. Application is Synced but Degraded

### Checks

```bash
kubectl -n <namespace> get pods
kubectl -n <namespace> describe pod <pod-name>
kubectl -n <namespace> logs <pod-name> --previous
kubectl -n <namespace> get events --sort-by=.lastTimestamp
```

### Likely causes

- Pod is in `CrashLoopBackOff`.
- Readiness or liveness probe is failing.
- Required Secret or ConfigMap is missing.
- Image tag is wrong or image cannot be pulled.
- Resource limits are too low and the pod is `OOMKilled`.

### Support response

I would explain that Argo CD successfully applied the desired manifests, but Kubernetes is reporting the workload as unhealthy. The issue is likely at the application/runtime layer, not necessarily Argo CD itself.

---

## 3. Repo-server cannot render manifests

### Checks

```bash
kubectl -n argocd logs deploy/argocd-repo-server -c argocd-repo-server
kubectl -n argocd exec deploy/argocd-repo-server -c argocd-repo-server -- helm version --short
```

### Likely causes

- Helm chart dependency issue.
- Invalid Helm values.
- Kustomize build error.
- Git authentication problem.
- Custom Helm binary failed to install or mount.

### Support response

Because manifest rendering happens in repo-server, I would check repo-server logs first for Helm/Kustomize errors. For this challenge, I would also verify the custom Helm version because the repo-server binary override is part of the setup.

---

## 4. Prometheus does not show Argo CD targets

### Checks

```bash
kubectl get servicemonitor -n monitoring
kubectl get svc -n argocd | grep metrics
kubectl get endpoints -n argocd | grep metrics
kubectl -n monitoring port-forward svc/monitoring-stack-kube-prom-prometheus 9090:9090
```

Open Prometheus targets:

```text
http://localhost:9090/targets
```

### Likely causes

- Prometheus Operator CRDs were not installed yet.
- ServiceMonitor selector labels do not match Prometheus configuration.
- Metrics service names or labels changed between Argo CD versions.
- Namespace selector does not include `argocd`.

### Support response

I would confirm whether ServiceMonitors exist, whether they select the correct Argo CD metrics services, and whether the Prometheus instance is configured to discover ServiceMonitors across namespaces.

---

## 5. Custom Helm version is not being used

### Checks

```bash
kubectl -n argocd describe deploy argocd-repo-server
kubectl -n argocd logs deploy/argocd-repo-server -c install-custom-helm
kubectl -n argocd exec deploy/argocd-repo-server -c argocd-repo-server -- helm version --short
```

### Likely causes

- Init container failed to download Helm.
- Volume mount path is incorrect.
- Container security policy blocks the mount.
- The repo-server image path for Helm changed.

### Support response

I would verify the init container completed successfully, then confirm the mounted file exists and is executable in the repo-server container. If the environment blocks downloading binaries at startup, I would recommend baking the required Helm version into a custom repo-server image instead.
