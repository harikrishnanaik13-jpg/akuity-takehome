#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="argocd"

printf "Creating namespace: %s\n" "$NAMESPACE"
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

printf "Installing/patching Argo CD from repository manifests...\n"
kubectl apply -k platform/argocd/overlays/default

printf "Waiting for Argo CD core deployments to become available...\n"
kubectl -n "$NAMESPACE" rollout status deploy/argocd-repo-server --timeout=240s
kubectl -n "$NAMESPACE" rollout status deploy/argocd-server --timeout=240s
kubectl -n "$NAMESPACE" rollout status deploy/argocd-applicationset-controller --timeout=240s || true

printf "Applying app-of-apps root Application...\n"
kubectl apply -f bootstrap/root-application.yaml

printf "\nBootstrap complete.\n"
printf "Next: update repo URLs, push to Git, then watch Applications with:\n"
printf "kubectl get applications -n argocd -w\n"
